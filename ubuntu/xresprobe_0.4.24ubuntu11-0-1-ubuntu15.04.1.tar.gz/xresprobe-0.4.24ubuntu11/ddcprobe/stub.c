#include <stdlib.h>
#include "common.h"

struct vbe_parent_info *vbe_get_vbe_info()
{
        struct vbe_info *ret = NULL;
        return ret;
}

int get_edid_supported()
{
        int ret = 0;
        return ret;
}

struct edid1_info *get_edid_info()
{
        struct edid1_info *ret = NULL;
        return ret;
}
